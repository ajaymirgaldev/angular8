1. Use Angular 8 cli
2. Create Component
3. Append HTML String to Container
4. Add click event to element
5. Create Service
5. Show List using service (HTTP) data
6. Add Style to List